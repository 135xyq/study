<template>
  <div class="app-container">
    <EditArticle mode="add"/>
  </div>
</template>

<script>
  import EditArticle from '@/components/EditArticle.vue'
  export default {
    components : {
      EditArticle
    }
  }
</script>

<style lang="scss" scoped>

</style>
