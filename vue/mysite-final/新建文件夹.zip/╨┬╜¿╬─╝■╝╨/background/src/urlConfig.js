// 导出服务器地址
export const server_URL = "http://127.0.0.1:7001";

// 导出前端地址
export const frontEnd_URL = "http://localhost:8080"
