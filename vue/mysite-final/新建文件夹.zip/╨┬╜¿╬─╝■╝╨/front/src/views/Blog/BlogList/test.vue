<template>
  <BlogList/>
</template>

<script>
import BlogList from './';
export default {
    components:{
        BlogList,
    }
}
</script>

<style>

</style>