import './banner';
import './blog';
import './setting';
import './about';
import './project';
import './message';

import Mock from 'mockjs';
// 设置延迟时间
Mock.setup({
    timeout: "500-1000",
});