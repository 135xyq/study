<template>
    <Icon type="qq"></Icon>
</template>

<script>
import Icon from "./";
export default{
	components:{
		Icon
	},
}
</script>

