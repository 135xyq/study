<template>
	<Avatar url="https://cdn4.buysellads.net/uu/1/3386/1525189943-38523.png"></Avatar>
</template>


<script>
import Avatar from "./";
export default{
	components:{
        Avatar
	},
}
</script>

<style scoped>

</style>

